<?php
/**
 * Admin functions MSP Helloworld plugin
 **/

 



?>